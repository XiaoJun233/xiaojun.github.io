package src.src;

public class User {
	private String name;
	private String Rank;
	private String Client;
	private String GameID;

	public User(String name, String ip, String Client, String GameID) {
		this.name = name;
		this.Client = Client;
		this.GameID = GameID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRank() {
		return Rank;
	}

	public void setRank(String ip) {
		this.Rank = ip;
	}

	public String getGameID() {
		return GameID;
	}

	public void setGameID(String GameID) {
		this.GameID = GameID;
	}

	public String getClient() {
		return Client;
	}

	public void setClient(String ip) {
		this.Client = ip;
	}
}
