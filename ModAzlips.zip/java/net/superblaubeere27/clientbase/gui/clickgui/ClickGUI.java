package net.superblaubeere27.clientbase.gui.clickgui;

import net.minecraft.client.gui.GuiScreen;
import net.superblaubeere27.clientbase.ClientBase;
import net.superblaubeere27.clientbase.Value.Numbers;
import net.superblaubeere27.clientbase.Value.Option;
import net.superblaubeere27.clientbase.Value.Value;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;
import net.superblaubeere27.clientbase.utils.render.RenderUtils;
import net.superblaubeere27.clientbase.utils.fontRenderer.CFontRenderer;
import net.superblaubeere27.clientbase.utils.fontRenderer.FontLoaders;

import java.awt.*;
import java.io.IOException;

public class ClickGUI extends GuiScreen {
    float x,y,height,width;
    private int listY;
    private boolean beingDragged;
    private ModuleCategory SelectType;
    private int dragX;
    private int dragY;
    Module selectmodule;
    boolean tooglesettings;
    int settingx,settingy;
    int settingynum;



    public ClickGUI(){
        SelectType = ModuleCategory.COMBAT;
    }

    public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY, boolean click) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }
        return false;
    }


    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if(mouseButton == 0) {

            // �϶�����
            if(isHovered(x,y,x+width,y+height / 18 + y + 2,mouseX,mouseY, true)){
                beingDragged = true;
                dragX = (int) (mouseX - this.x);
                dragY = (int) (mouseY - this.y);
            }

            //ѡ������
            boolean isCombat = false;
            boolean isRender = false;
            boolean isMove = false;
            boolean isPlayer = false;
            boolean isWorld = false;

            int i = 0;
            for (ModuleCategory mc : ModuleCategory.values()) {
                isCombat = mouseX > x + i * (width / ModuleCategory.values().length + 1)
                        && mouseX < x + i * (width / ModuleCategory.values().length + 1) + (width / ModuleCategory.values().length + 1) - 1
                        && mouseY > height / 18 + y + 2 && mouseY < y + height / 6 - 1 && i == 0;
                isRender = mouseX > x + i * (width / ModuleCategory.values().length + 1)
                        && mouseX < x + i * (width / ModuleCategory.values().length + 1) + (width / ModuleCategory.values().length + 1) - 1
                        && mouseY > height / 18 + y + 2 && mouseY < y + height / 6 - 1 && i == 1;
                isMove = mouseX > x + i * (width / ModuleCategory.values().length + 1)
                        && mouseX < x + i * (width / ModuleCategory.values().length + 1) + (width / ModuleCategory.values().length + 1) - 1
                        && mouseY > height / 18 + y + 2 && mouseY < y + height / 6 - 1 && i == 2;
                isPlayer = mouseX > x + i * (width / ModuleCategory.values().length + 1)
                        && mouseX < x + i * (width / ModuleCategory.values().length + 1) + (width / ModuleCategory.values().length + 1) - 1
                        && mouseY > height / 18 + y + 2 && mouseY < y + height / 6 - 1 && i == 3;
                isWorld = mouseX > x + i * (width / ModuleCategory.values().length + 1)
                        && mouseX < x + i * (width / ModuleCategory.values().length + 1) + (width / ModuleCategory.values().length + 1) - 1
                        && mouseY > height / 18 + y + 2 && mouseY < y + height / 6 - 1 && i == 4;
                if (isCombat) {
                    SelectType = ModuleCategory.COMBAT;
                    tooglesettings = false;
                }
                if (isRender) {
                    SelectType = ModuleCategory.RENDER;
                    tooglesettings = false;
                }
                if (isMove) {
                    SelectType = ModuleCategory.MOVE;
                    tooglesettings = false;
                }
                if (isPlayer) {
                    SelectType = ModuleCategory.PLAYER;
                    tooglesettings = false;
                }
                if (isWorld) {
                    SelectType = ModuleCategory.WORLD;
                    tooglesettings = false;
                }
                i++;
            }
            //��������
            CFontRenderer font = FontLoaders.Comfortaa16;
            int a= (int)(height/6+y)+5;
            for(Module m:ClientBase.INSTANCE.moduleManager.getModules()){
                if(m.getCategory() == SelectType) {
                    if(m.getState()){
                        font.drawString(m.getName(), x + 5, a, new Color(100, 100, 255).getRGB());
                    }else{
                        font.drawString(m.getName(), x + 5, a, new Color(100, 100, 100).getRGB());
                    }

                    if(isHovered(x+5,a,x+width/5+1,a+font.getHeight(),mouseX,mouseY, true)){
                        m.setState(!m.getState());
                    }

                    a += font.getStringHeight("") + 4;
                }
            }
            //�O��Option
            if (selectmodule != null){
                if (selectmodule.getValues() != null) {
                    for (Value va : selectmodule.getValues()) {
                        if (va instanceof Option) {
                            Option v = (Option) va;
                            if (mouseX > settingx && mouseX < settingx + 10 && mouseY > settingy-30 && mouseY < settingy -20) {
                                va.setValue(!(Boolean) va.getValue());
                            }
                            int optionnum = 0;
                            for (Value val : selectmodule.getValues()) {
                                if (val instanceof Option) {
                                    optionnum++;
                                }
                            }
                            if (settingy < settingy + optionnum * 15) {
                                settingy += 15;
                            } else {
                                settingy = (int) (height / 6 + y) + 5;
                            }
                        }



                    }
                }
        }
        }


        //Option
        if(tooglesettings){
            if(selectmodule.getValues() !=null) {
                for (Value va : selectmodule.getValues()) {
                    if (va instanceof Option) {
                        Option v = (Option) va;
                        if((boolean)v.getValue()) {
                            drawRect(settingx, settingy, settingx + 10, settingy + 10, -1);
                        }else{
                            drawRect(settingx, settingy, settingx + 10, settingy + 10, new Color(100,100,100).getRGB());
                        }

                        if(mouseX>settingx&&mouseX<settingx+10&&mouseY>settingy-35&&mouseY<settingy-20){
                            va.setValue(!(Boolean) va.getValue());
                        }
                        int optionnum=0;
                        for(Value val : selectmodule.getValues()){
                            if (val instanceof Option) {
                                optionnum++;
                            }
                        }
                        if(settingy<settingy+optionnum*15) {
                            settingy += 15;
                        }else{
                            settingy =(int) (height/6+y)+5;
                        }
                    }

                }
            }
        }

        if(mouseButton == 1){
            //������������
            CFontRenderer font = FontLoaders.Comfortaa16;
            int a= (int)(height/6+y)+5;
            for(Module m:ClientBase.INSTANCE.moduleManager.getModules()){
                if(m.getCategory() == SelectType) {
                    if(mouseX>x + 1&&mouseX<width/5+x+1&&mouseY>a-font.getHeight()/2&&mouseY<a+font.getHeight()){
                        selectmodule = m;
                        tooglesettings = !tooglesettings;
                    }
                    a += font.getStringHeight("") + 4;
                }
            }

        }

    }
    @Override
    public void mouseReleased(int button, int x, int y) {
        beingDragged = false;
    }

    @Override
    public void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick){

        if(tooglesettings){
            if(selectmodule.getValues() !=null) {
                for (Value va : selectmodule.getValues()) {
                    //Numbers

                    if (va instanceof Numbers) {
                        Numbers v = (Numbers) va;
                        //drawRect(settingx, settingy+10, settingx + 80, settingy + 14, new Color(70,70,70).getRGB());
                        double width = ((double)v.getValue() / (v.getMaximum().doubleValue()-v.getMinimum().doubleValue()))*80;
                        if(isHovered(settingx, settingy+10, settingx + 80, settingy + 14,mouseX,mouseY,true)){
                            double i = (double)((mouseX - settingx)/80D*(v.getMaximum().doubleValue()-v.getMinimum().doubleValue()));
                            v.setValue(3+i);
                        }
                        int optionnum=0;
                        for(Value val : selectmodule.getValues()){
                            if (val instanceof Numbers) {
                                optionnum++;
                            }
                        }
                        if(settingy<settingy+optionnum*15) {
                            settingy += 15;
                        }else{
                            settingy =(int) (height/6+y)+5;
                        }
                    }


                }
            }
        }


        if(beingDragged) {
            drag((int) mouseX, (int) mouseY);
        }
    }

    private void drag(int mouseX, int mouseY) {
        if (beingDragged) {
            this.x = mouseX - dragX;
            this.y = mouseY - dragY;
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        settingx = (int) (width/5+x+5);
        settingy = (int) (height/6+y)+5;
        height=mc.displayHeight/4;
        width = mc.displayWidth/4;
        //����
        RenderUtils.drawRect(x,y+5,width+x,height+y,new Color(50,50,60).getRGB());
        //ѡ����
        RenderUtils.drawRect(x,y+5,width+x,height/6+y,new Color(80,80,100).getRGB());
        RenderUtils.drawRect(x,y,width+x,y+5,new Color(80,80,100).getRGB());
        RenderUtils.drawRect(x,y,width+x,y+1,new Color(130,130,255).getRGB());
        //RenderUtils.drawRect(x-1,y,x,y+height,new Color(130,130,255).getRGB());
        //RenderUtils.drawRect(x+width,y,x+width+1,y+height,new Color(130,130,255).getRGB());
        //RenderUtils.drawRect(x,y+height,width+x,y+height+1,new Color(130,130,255).getRGB());
        //���������÷ָ���
        RenderUtils.drawRect(x+width/5,height/6+y,width/5+x+1,height+y,new Color(255,255,255,90).getRGB());
        //����
        CFontRenderer font = FontLoaders.Comfortaa16;
        int i=0;
        for(ModuleCategory mc : ModuleCategory.values()){
            if(SelectType == mc){
                font.drawString(mc.name(),x+(i)*(width/ModuleCategory.values().length)+10,y+height/12,new Color(255,255,255).getRGB());
            }else{
                font.drawString(mc.name(),x+(i)*(width/ModuleCategory.values().length)+10,y+height/12,new Color(200,200,200).getRGB());
            }
            i++;
        }
        //�����б�
        int a= (int)(height/6+y)+5;
        for(Module m:ClientBase.INSTANCE.moduleManager.getModules()){
            if(m.getCategory() == SelectType) {
                if(width/5+x+1 < x + 1+ font.getStringWidth(m.getName())){
                }
                if(m.getState()){
                    font.drawString(m.getName(), x + 5, a, new Color(100, 100, 255).getRGB());
                }else{
                    font.drawString(m.getName(), x + 5, a, new Color(100, 100, 100).getRGB());
                }

                a += font.getStringHeight("") + 4;
            }
        }
        RenderUtils.drawRect(x+width/5+1,height/6+y,x+width,height+y,new Color(50,50,60).getRGB());
        //���ý���
        if(tooglesettings){
            if(selectmodule.getValues() !=null) {
                for (Value va : selectmodule.getValues()) {
                    //Option
                    if (va instanceof Option) {
                        Option v = (Option) va;
                        if((boolean)v.getValue()) {
                            drawRect(settingx+3, settingy+3, settingx + 10, settingy + 10, -1);
                            font.drawString(va.getDisplayName(), settingx + 15, settingy + 4, new Color(255, 255, 255).getRGB());
                        }else{
                            drawRect(settingx+3, settingy+3, settingx + 10, settingy + 10, new Color(100,100,100).getRGB());
                            font.drawString(va.getDisplayName(), settingx + 15, settingy + 4, new Color(100, 100, 100).getRGB());
                        }
                        int optionnum=0;
                        for(Value val : selectmodule.getValues()){
                            if (val instanceof Option) {
                                optionnum++;
                            }
                        }
                        if(settingy<settingy+optionnum*15) {
                            settingy += 15;
                        }else{
                            settingy =(int) (height/6+y)+5;
                        }
                    }

                    //Double
                    if (va instanceof Numbers) {
                        Numbers v = (Numbers) va;
                        font.drawString(va.getDisplayName()+" - "+va.getValue(), settingx, settingy + 3, new Color(100, 100, 200).getRGB());
                        drawRect(settingx, settingy+10, settingx + 80, settingy + 14, new Color(70,70,70).getRGB());
                        double width = ((double)v.getValue() / (v.getMaximum().doubleValue()-v.getMinimum().doubleValue()))*80;
                        drawRect(settingx, settingy+10, settingx + (int)width-80, settingy + 14, new Color(100,100,255).getRGB());
                        int optionnum=0;


                        for(Value val : selectmodule.getValues()){
                            if (val == v) {
                                settingy =(int) (height/6+y)+5;
                            }
                            if (val instanceof Option) {
                                optionnum++;
                            }
                        }
                        if(settingy<settingy+optionnum*15) {
                            settingy += 15;
                        }else{
                            settingy =(int) (height/6+y)+5;
                        }
                    }
                }
            }else{
                font.drawString("No Stttings Here.",settingx,settingy,new Color(100,100,100).getRGB());
            }
        }
    }
}
