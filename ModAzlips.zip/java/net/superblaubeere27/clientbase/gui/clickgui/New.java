/*
 * Decompiled with CFR 0.136.
 */
package net.superblaubeere27.clientbase.gui.clickgui;

import java.awt.Color;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.superblaubeere27.clientbase.ClientBase;
import net.superblaubeere27.clientbase.Value.Mode;
import net.superblaubeere27.clientbase.Value.Numbers;
import net.superblaubeere27.clientbase.Value.Option;
import net.superblaubeere27.clientbase.Value.Value;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;
import net.superblaubeere27.clientbase.utils.fontRenderer.CFontRenderer;
import net.superblaubeere27.clientbase.utils.fontRenderer.FontLoaders;
import net.superblaubeere27.clientbase.utils.render.RenderUtil;
import org.lwjgl.input.Mouse;

public class New extends GuiScreen{
    public static ModuleCategory currentModuleType = ModuleCategory.COMBAT;
    public static Module currentModule = ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).size() != 0
            ?  ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).get(0)
            : null;
    public static float startX = 100, startY = 100;
    public int moduleStart = 0;
    public int valueStart = 0;
    boolean previousmouse = true;
    boolean mouse;
    public Opacity opacity = new Opacity(0);
    public int opacityx = 255;
    public float moveX = 0, moveY = 0;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (isHovered(startX, startY - 25, startX + 400, startY + 25, mouseX, mouseY) && Mouse.isButtonDown(0)) {
            if (moveX == 0 && moveY == 0) {
                moveX = mouseX - startX;
                moveY = mouseY - startY;
            } else {
                startX = mouseX - moveX;
                startY = mouseY - moveY;
            }
            this.previousmouse = true;
        } else if (moveX != 0 || moveY != 0) {
            moveX = 0;
            moveY = 0;
        }
        this.opacity.interpolate((float) opacityx);
        RenderUtil.drawRect(startX, startY, startX + 60, startY + 320,
                new Color(40, 40, 40, (int) opacity.getOpacity()).getRGB());
        RenderUtil.drawRect(startX + 60, startY, startX + 200, startY + 320,
                new Color(31, 31, 31, (int) opacity.getOpacity()).getRGB());
        RenderUtil.drawRect(startX + 200, startY, startX + 420, startY + 320,
                new Color(40, 40, 40, (int) opacity.getOpacity()).getRGB());
        for (int i = 0; i < ModuleCategory.values().length; i++) {
            ModuleCategory[] iterator = ModuleCategory.values();
            if (iterator[i] != currentModuleType) {
                RenderUtil.drawFilledCircle(startX + 30, startY + 30 + i * 40, 15,
                        new Color(56, 56, 56, (int) opacity.getOpacity()).getRGB(), 5);
            } else {
                RenderUtil.drawFilledCircle(startX + 30, startY + 30 + i * 40, 15,
                        new Color(101, 81, 255, (int) opacity.getOpacity()).getRGB(), 5);
            }
            try {
                if (this.isCategoryHovered(startX + 15, startY + 15 + i * 40, startX + 45, startY + 45 + i * 40, mouseX,
                        mouseY) && Mouse.isButtonDown((int) 0)) {
                    currentModuleType = iterator[i];
                    currentModule =  ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).size() != 0
                            ? ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).get(0)
                            : null;
                    moduleStart = 0;
                }
            } catch (Exception e) {
                System.err.println(e);
            }
        }
        int m = Mouse.getDWheel();
        if (this.isCategoryHovered(startX + 60, startY, startX + 200, startY + 320, mouseX, mouseY)) {
            if (m < 0 && moduleStart < ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).size() - 1) {
                moduleStart++;
            }
            if (m > 0 && moduleStart > 0) {
                moduleStart--;
            }
        }
        if (this.isCategoryHovered(startX + 200, startY, startX + 420, startY + 320, mouseX, mouseY)) {
            if (m < 0 && valueStart < currentModule.getValues().size() - 1) {
                valueStart++;
            }
            if (m > 0 && valueStart > 0) {
                valueStart--;
            }
        }
            FontLoaders.Comfortaa18.drawString(
                    currentModule == null ? currentModuleType.toString()
                            : currentModuleType.toString() + "/" + currentModule.getName(),
                    startX + 70, startY + 15, new Color(212, 242, 231).getRGB());
        if (currentModule != null) {
            float mY = startY + 30;
            for (int i = 0; i < ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).size(); i++) {
                Module module = ClientBase.INSTANCE.moduleManager.getmodsbycategory(currentModuleType).get(i);
                if (mY > startY + 300)
                    break;
                if (i < moduleStart) {
                    continue;
                }

                RenderUtil.drawRect(startX + 75, mY, startX + 185, mY + 2,
                        new Color(40, 40, 40, (int) opacity.getOpacity()).getRGB());
                    FontLoaders.Comfortaa24.drawString(module.getName(), startX + 90, mY + 11,
                            new Color(212, 242, 231, (int) opacity.getOpacity()).getRGB());
                if (!module.getState()) {
                    RenderUtil.drawFilledCircle(startX + 75, mY + 13, 2,
                            new Color(255, 0, 0, (int) opacity.getOpacity()).getRGB(), 5);
                } else {
                    RenderUtil.drawFilledCircle(startX + 75, mY + 13, 2,
                            new Color(0, 255, 0, (int) opacity.getOpacity()).getRGB(), 5);
                }
                if (isSettingsButtonHovered(startX + 90, mY,
                        startX + 100 + (FontLoaders.Comfortaa24.getStringWidth(module.getName())),
                        mY + 8 + FontLoaders.Comfortaa24.getHeight(), mouseX, mouseY)) {
                    if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                        if (module.getState()) {
                            module.setState(false);
                        } else {
                            module.setState(true);
                        }
                        previousmouse = true;
                    }
                    if (!this.previousmouse && Mouse.isButtonDown((int) 1)) {
                        previousmouse = true;
                    }
                }

                if (!Mouse.isButtonDown((int) 0)) {
                    this.previousmouse = false;
                }
                if (isSettingsButtonHovered(startX + 90, mY,
                        startX + 100 + (FontLoaders.Comfortaa20.getStringWidth(module.getName())),
                        mY + 8 + FontLoaders.Comfortaa20.getHeight(), mouseX, mouseY) && Mouse.isButtonDown((int) 1)) {
                    currentModule = module;
                    valueStart = 0;
                }
                mY += 25;
            }
            mY = startY + 30;
            for (int i = 0; i < currentModule.getValues().size(); i++) {
                if (mY > startY + 300)
                    break;
                if (i < valueStart) {
                    continue;
                }
                CFontRenderer font = FontLoaders.Comfortaa18;
                Value value = currentModule.getValues().get(i);
                if (value instanceof Numbers) {
                    float x = startX + 300;
                    double render = (double) (68.0F
                            * (((Number) value.getValue()).floatValue() - ((Numbers) value).getMinimum().floatValue())
                            / (((Numbers) value).getMaximum().floatValue()
                            - ((Numbers) value).getMinimum().floatValue()));
                    RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + 75), mY + 3,
                            (new Color(50, 50, 50, (int) opacity.getOpacity())).getRGB());
                    RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + render + 6.5D), mY + 3,
                            (new Color(61, 141, 255, (int) opacity.getOpacity())).getRGB());
                    RenderUtil.drawRect((float) ((double) x + render + 2D), mY, (float) ((double) x + render + 7D),
                            mY + 5, (new Color(61, 141, 255, (int) opacity.getOpacity())).getRGB());
                    font.drawStringWithShadow(value.getName() + ": " + value.getValue(), startX + 210, mY, -1);
                    if (!Mouse.isButtonDown((int) 0)) {
                        this.previousmouse = false;
                    }
                    if (this.isButtonHovered(x, mY - 2, x + 100, mY + 7, mouseX, mouseY)
                            && Mouse.isButtonDown((int) 0)) {
                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                            render = ((Numbers) value).getMinimum().doubleValue();
                            double max = ((Numbers) value).getMaximum().doubleValue();
                            double inc = ((Numbers) value).getIncrement().doubleValue();
                            double valAbs = (double) mouseX - ((double) x + 1.0D);
                            double perc = valAbs / 68.0D;
                            perc = Math.min(Math.max(0.0D, perc), 1.0D);
                            double valRel = (max - render) * perc;
                            double val = render + valRel;
                            val = (double) Math.round(val * (1.0D / inc)) / (1.0D / inc);
                            ((Numbers) value).setValue(Double.valueOf(val));
                        }
                        if (!Mouse.isButtonDown((int) 0)) {
                            this.previousmouse = false;
                        }
                    }
                    mY += 20;
                }
                if (value instanceof Option) {
                    float x = startX + 300;
                    font.drawStringWithShadow(value.getName(), startX + 210, mY, -1);
                    RenderUtil.drawRect(x + 56, mY, x + 76, mY + 1,
                            new Color(255, 255, 255, (int) opacity.getOpacity()).getRGB());
                    RenderUtil.drawRect(x + 56, mY + 8, x + 76, mY + 9,
                            new Color(255, 255, 255, (int) opacity.getOpacity()).getRGB());
                    RenderUtil.drawRect(x + 56, mY, x + 57, mY + 9,
                            new Color(255, 255, 255, (int) opacity.getOpacity()).getRGB());
                    RenderUtil.drawRect(x + 76, mY, x + 77, mY + 9,
                            new Color(255, 255, 255, (int) opacity.getOpacity()).getRGB());
                    if ((boolean) value.getValue()) {
                        RenderUtil.drawRect(x + 67, mY + 2, x + 75, mY + 7,
                                new Color(61, 141, 255, (int) opacity.getOpacity()).getRGB());
                    } else {
                        RenderUtil.drawRect(x + 58, mY + 2, x + 65, mY + 7,
                                new Color(150, 150, 150, (int) opacity.getOpacity()).getRGB());
                    }
                    if (this.isCheckBoxHovered(x + 56, mY, x + 76, mY + 9, mouseX, mouseY)) {
                        if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
                            this.previousmouse = true;
                            this.mouse = true;
                        }

                        if (this.mouse) {
                            value.setValue(!(boolean) value.getValue());
                            this.mouse = false;
                        }
                    }
                    if (!Mouse.isButtonDown((int) 0)) {
                        this.previousmouse = false;
                    }
                    mY += 20;
                }
                if (value instanceof Mode) {
                    float x = startX + 300;
                    font.drawStringWithShadow(value.getName(), startX + 210, mY, -1);
                    RenderUtil.drawRect(x - 5, mY - 5, x + 90, mY + 15,
                            new Color(56, 56, 56, (int) opacity.getOpacity()).getRGB());
                    RenderUtil.drawBorderRect(x - 5, mY - 5, x + 90, mY + 15,
                            new Color(101, 81, 255, (int) opacity.getOpacity()).getRGB(), 2);
                    font.drawStringWithShadow(((Mode) value).getModeAsString(),
                            (float) (x + 40 - font.getStringWidth(((Mode) value).getModeAsString()) / 2), mY, -1);
                    if (this.isStringHovered(x, mY - 5, x + 100, mY + 15, mouseX, mouseY)) {
                        if (Mouse.isButtonDown((int) 0) && !this.previousmouse) {
                            Enum current = (Enum) ((Mode) value).getValue();
                            int next = current.ordinal() + 1 >= ((Mode) value).getModes().length ? 0
                                    : current.ordinal() + 1;
                            value.setValue(((Mode) value).getModes()[next]);
                            this.previousmouse = true;
                        }
                        if (!Mouse.isButtonDown((int) 0)) {
                            this.previousmouse = false;
                        }

                    }
                    mY += 25;
                }
            }
        }

    }

    public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
            return true;
        }

        return false;
    }

    @Override
    public void onGuiClosed() {
        this.opacity.setOpacity(0);
    }
}
