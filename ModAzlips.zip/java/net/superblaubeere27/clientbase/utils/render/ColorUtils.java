package net.superblaubeere27.clientbase.utils.render;

import java.awt.*;

public class ColorUtils {
    public static final int SELECT = new Color(33, 170, 47).getRGB();
    public static final int BG = new Color(23, 23, 23).getRGB();
    public static final int TOGGLE = new Color(123, 123, 123).getRGB();
    public static final int CHECK_BG = new Color(123, 123, 123).getRGB();
    public static final int CHECK_TOGGLE = new Color(123, 233, 123).getRGB();

}
