package net.superblaubeere27.clientbase.utils.fontRenderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;

import java.awt.Font;
import java.io.InputStream;
import java.io.PrintStream;

public abstract class FontLoaders {
	public static CFontRenderer Comfortaa16 = new CFontRenderer(FontLoaders.getComfortaa(16), true, true);
	public static CFontRenderer Comfortaa18 = new CFontRenderer(FontLoaders.getComfortaa(18), true, true);
	public static CFontRenderer Comfortaa20 = new CFontRenderer(FontLoaders.getComfortaa(20), true, true);
	public static CFontRenderer Comfortaa22 = new CFontRenderer(FontLoaders.getComfortaa(22), true, true);
	public static CFontRenderer Comfortaa24 = new CFontRenderer(FontLoaders.getComfortaa(24), true, true);
	public static CFontRenderer Comfortaa26 = new CFontRenderer(FontLoaders.getComfortaa(26), true, true);
	public static CFontRenderer Comfortaa28 = new CFontRenderer(FontLoaders.getComfortaa(28), true, true);

	public static CFontRenderer GoogleSans16 = new CFontRenderer(FontLoaders.getGoogleSans(16), true, true);
	public static CFontRenderer GoogleSans18 = new CFontRenderer(FontLoaders.getGoogleSans(18), true, true);
	public static CFontRenderer GoogleSans20 = new CFontRenderer(FontLoaders.getGoogleSans(20), true, true);
	public static CFontRenderer GoogleSans22 = new CFontRenderer(FontLoaders.getGoogleSans(22), true, true);
	public static CFontRenderer GoogleSans24 = new CFontRenderer(FontLoaders.getGoogleSans(24), true, true);
	public static CFontRenderer GoogleSans26 = new CFontRenderer(FontLoaders.getGoogleSans(26), true, true);
	public static CFontRenderer GoogleSans28 = new CFontRenderer(FontLoaders.getGoogleSans(28), true, true);
	public static CFontRenderer GoogleSans35 = new CFontRenderer(FontLoaders.getGoogleSans(35), true, true);

	private static Font getComfortaa(int size) {
		Font font;
		try {
			InputStream is = Minecraft.getMinecraft().getResourceManager()
					.getResource(new ResourceLocation("client/font/Comfortaa.ttf")).getInputStream();
			font = Font.createFont(0, is);
			font = font.deriveFont(0, size);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Error loading font");
			font = new Font("default", 0, size);
		}
		return font;
	}

	private static Font getGoogleSans(int size) {
		Font font;
		try {
			InputStream is = Minecraft.getMinecraft().getResourceManager()
					.getResource(new ResourceLocation("NovAssets/FONT/GoogleSans.ttf")).getInputStream();
			font = Font.createFont(0, is);
			font = font.deriveFont(0, size);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Error loading font");
			font = new Font("default", 0, size);
		}
		return font;
	}
}
