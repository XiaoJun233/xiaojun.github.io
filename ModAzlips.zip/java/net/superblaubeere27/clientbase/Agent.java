package net.superblaubeere27.clientbase;

import java.lang.instrument.Instrumentation;

import net.minecraft.launchwrapper.LaunchClassLoader;
import net.superblaubeere27.clientbase.injection.MixinLoader;

public class Agent {
    public static void agentmain(String args, Instrumentation instrumentation) throws Exception {
        for (Class<?> classes : instrumentation.getAllLoadedClasses()) {
            if (classes.getName().startsWith("net.minecraft.client.Minecraft")) {
                LaunchClassLoader classLoader = (LaunchClassLoader)classes.getClassLoader();
                classLoader.addURL(Agent.class.getProtectionDomain().getCodeSource().getLocation());
                Class<?> client = classLoader.loadClass(ClientBase.class.getName());client.newInstance();
            }
        }
    }
}
