package net.superblaubeere27.clientbase.injection.mixins;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.superblaubeere27.clientbase.ClientBase;
import net.superblaubeere27.clientbase.command.Command;
import net.superblaubeere27.clientbase.events.EventChat;
import net.superblaubeere27.clientbase.modules.ModuleManager;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiScreen.class)
@SideOnly(Side.CLIENT)
public class MixinGuiScreen {
    @Shadow
    public Minecraft mc;

    @Shadow
    public void sendChatMessage(String msg, boolean addToChat) {

    }
    @Overwrite
    public void sendChatMessage(String msg)
    {
        if(msg.startsWith("-") && ClientBase.INSTANCE.moduleManager.getModule("Commands",false).getState()){
            mc.thePlayer.addChatMessage(new ChatComponentText( msg.substring(1)));
            return;
        }
        this.sendChatMessage(msg, true);
    }
}
