package net.superblaubeere27.clientbase.events;

import com.darkmagician6.eventapi.events.Event;


public class EventChat implements Event{
    private String leftOfCursor;
    public EventChat(String p_146405_1_){
        leftOfCursor=p_146405_1_;
    }
    public String getLeftOfCursor(){
        return this.leftOfCursor;
    }
}
