package net.superblaubeere27.clientbase.modules.modules.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.superblaubeere27.clientbase.Value.Option;
import net.superblaubeere27.clientbase.events.MotionUpdateEvent;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;

public class Sprint extends Module {
    public Option<Boolean> always = new Option<Boolean>("Always","Always",false);
    public Sprint() {
        super("Sprint", "make you keep sprint", ModuleCategory.MOVE);
        this.addValues(always);
    }
    @EventTarget
    public void onUpdate(MotionUpdateEvent e){
        if(always.getValue()) {
            if (mc.thePlayer.movementInput.moveForward != 0 || mc.thePlayer.movementInput.moveStrafe != 0) {
                mc.thePlayer.setSprinting(true);
            }
        }else{
            if (mc.thePlayer.movementInput.moveForward > 0 || (mc.thePlayer.movementInput.moveStrafe != 0 && mc.thePlayer.movementInput.moveForward > 0)) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }
}
