package net.superblaubeere27.clientbase.modules.modules.combat;

import net.superblaubeere27.clientbase.Value.Numbers;
import net.superblaubeere27.clientbase.Value.Option;
import net.superblaubeere27.clientbase.Value.Value;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;


public class Reach extends Module {
    public static Numbers<Double> range = new Numbers<Double>("Range","Range",3.5,3.0,6.0,0.1);
    public Option inwater = new Option("Water Check","Water Check",false);
    public static Numbers<Double> range2 = new Numbers<Double>("Range","Range",3.5,3.0,6.0,0.1);
    public Option inwater2 = new Option("Water Check","Water Check",false);
    public Reach() {
        super("Reach", "attack reach", ModuleCategory.COMBAT);
        this.addValues(range,inwater,range2,inwater2);
    }
}
