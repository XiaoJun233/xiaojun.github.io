package net.superblaubeere27.clientbase.modules.modules.combat;

import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;

public class Killaura extends Module {

    protected Killaura() {
        super("Killaura", "Auto Attack.", ModuleCategory.COMBAT);
    }
}
