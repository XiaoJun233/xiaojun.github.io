package net.superblaubeere27.clientbase.modules.modules.World;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.ChatComponentText;
import net.superblaubeere27.clientbase.events.EventChat;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;

public class Commands extends Module {

    public Commands() {
        super("Commands", "use client command with -", ModuleCategory.WORLD);
    }

    @EventTarget
    public void onChat(EventChat e){
            mc.thePlayer.addChatMessage(new ChatComponentText(String.format("%s%s", e.getLeftOfCursor().substring(1))));
            System.out.println("SB");
    }

}
