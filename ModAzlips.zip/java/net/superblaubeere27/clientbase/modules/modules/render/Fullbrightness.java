package net.superblaubeere27.clientbase.modules.modules.render;

import com.darkmagician6.eventapi.EventTarget;
import net.superblaubeere27.clientbase.modules.Module;
import net.superblaubeere27.clientbase.modules.ModuleCategory;

public class Fullbrightness extends Module {
    private float old;
    public Fullbrightness() {
        super("Fullbrightness", "Light!!", ModuleCategory.RENDER);
    }
    @Override
    public void onEnable(){
        old = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting=10f;
    }

    @Override
    public void onDisable(){
        mc.gameSettings.gammaSetting=old;
    }
}
